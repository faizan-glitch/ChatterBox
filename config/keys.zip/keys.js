export const keys = {
  SessionSecret: 'NodeJSIsFuckingAmazing',
  MONGODB: {
    username: 'faizan',
    password: 'catsandrainbows',
    URI: 'mongodb+srv://faizan:catsandrainbows@cluster0-th6jx.mongodb.net/ChatterBox?retryWrites=true&w=majority'
  }
};